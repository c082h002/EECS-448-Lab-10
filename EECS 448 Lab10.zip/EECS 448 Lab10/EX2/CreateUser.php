<?php
$database_URL = 'mysql.eecs.ku.edu';
$my_user = 'chenyuhao';
$my_password = 'iheec3bo';
$database_name = 'chenyuhao';
$mysqli = new mysqli($database_URL,$my_user, $my_password, $database_name);
if ($mysqli->connect_errno) {
    printf("Connect failed: %s\n", $mysqli->connect_error);
    exit();
}
$user_id = $_POST["user_id"];

if($user_id == '')
{
	echo "Empty Input !";
}
else
{
  $query = "INSERT INTO Users (user_id) VALUES ('$user_id')";

  if($mysqli->query($query) === TRUE)
  {
	   echo "Creating new user Succeed !";
	}
  else
  {
	   echo "The User Already Exists";
  }
}

$mysqli->close();
?>
